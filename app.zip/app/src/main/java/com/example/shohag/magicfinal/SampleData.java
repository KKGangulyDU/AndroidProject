package com.example.shohag.magicfinal;

import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class SampleData {

    static List<String> youtube_id_list = new ArrayList<>();
    static List<String> youtube_id_list_test = new ArrayList<>();

    String[] web = {
            "Google",
            "Github",
            "Instagram",
            "Facebook",
            "Flickr",
            "Pinterest",
            "Quora",
            "Twitter",
            "Vimeo",
            "WordPress",
            "Youtube",
            "Stumbleupon",
            "SoundCloud",
            "Reddit",
            "Blogger"
    };
    int[] imageId = {
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher,
            R.drawable.ic_launcher
    };
    static String[] youtube_id = {

            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
            "b7pjiYr-Bpo",
            "U4YR67ndqlc",
            "VZEWqfjOZbU",
    };

    static String[][] youtube_id_test = {
            {"b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",},
            {"b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",},
            {"b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",
                    "b7pjiYr-Bpo",
                    "U4YR67ndqlc",
                    "VZEWqfjOZbU",}


    };


    public static List<String> getYoutubeThamNailData() {
        Log.d("XXXXXXXXXXXXXXX", "Get Youtube id data");

        for (int i = 0; i < youtube_id.length; i++)
            youtube_id_list.add(youtube_id[i]);


        return youtube_id_list;
    }


    //    public  static List<String> getYoutubeThamNailData_test(){
//
//        for(int i=0;i<youtube_id_test.length;i++)
//            youtube_id_list_test.add(youtube_id_test[i]);
//
//
//        return youtube_id_list_test;
//    }
    static int flag_index = 0;

    public static List<String> getYoutubeData() {
        youtube_id_list.clear();

        for (int i = 0; i < youtube_id_test[flag_index].length; i++) {
            youtube_id_list.add(youtube_id_test[flag_index][i]);

        }
        //flag_index ++;
        return youtube_id_list;

    }
}
